// IH3: Toggle More Details for each quiz
function toggleDetails(button) {
    const details = button.nextElementSibling;
    details.classList.toggle('hidden');
    button.textContent = details.classList.contains('hidden') ? 'More Details' : 'Less Details';
}

// IH5: Clicking the header goes to home page (already linked in header in HTML)

// IH6: Show Help message
function toggleHelp() {
    const helpText = document.getElementById('help-text');
    helpText.classList.toggle('hidden');
}

// IH7: Filter quizzes by search criteria
function filterQuizzes() {
    const nameFilter = document.getElementById('search-name').value.toLowerCase();
    const categoryFilter = document.getElementById('search-category').value;
    const difficultyFilter = document.getElementById('search-difficulty').value;

    const quizzes = document.querySelectorAll('.quiz-item');

    quizzes.forEach(quiz => {
        const matchesName = quiz.querySelector('h3').textContent.toLowerCase().includes(nameFilter);
        const matchesCategory = categoryFilter === 'all' || quiz.dataset.category.toLowerCase() === categoryFilter;
        const matchesDifficulty = difficultyFilter === 'all' || quiz.dataset.difficulty.toLowerCase() === difficultyFilter;

        if (matchesName && matchesCategory && matchesDifficulty) {
            quiz.style.display = '';
        } else {
            quiz.style.display = 'none';
        }
    });
}

// IH8: Favorite and Save for Later buttons
function toggleFavorite(button) {
    button.classList.toggle('active');
    button.textContent = button.classList.contains('active') ? 'Favorited' : 'Favorite';
}

function toggleSaveLater(button) {
    button.classList.toggle('active');
    button.textContent = button.classList.contains('active') ? 'Saved' : 'Save for Later';
}
