from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

users = {}  # Temporary in-memory user storage
quizzes = [
    {"title": "Math Quiz", "category": "Math", "difficulty": "Easy", "details": "A fun math quiz to test your skills!"},
    {"title": "Science Quiz", "category": "Science", "difficulty": "Medium", "details": "Learn about science basics!"},
    {"title": "History Quiz", "category": "History", "difficulty": "Hard", "details": "Dive into historical events!"},
]

# Root route displays the login page by default
@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('home'))
    return redirect(url_for('login'))

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in users and users[username] == password:
            session['username'] = username
            flash("Login successful!", "success")
            return redirect(url_for('home'))
        else:
            flash("Invalid username or password.", "error")
    
    return render_template('login.html')

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in users:
            flash("Username already exists!", "error")
        else:
            users[username] = password
            flash("Registration successful! Please log in.", "success")
            return redirect(url_for('login'))
    
    return render_template('register.html')

# Home route
@app.route('/home')
def home():
    if 'username' not in session:
        flash("Please log in to access the home page.", "error")
        return redirect(url_for('login'))
    return render_template('home.html')

# Browse quizzes route
@app.route('/browse')
def browse():
    if 'username' not in session:
        flash("Please log in to browse quizzes.", "error")
        return redirect(url_for('login'))
    return render_template('browse.html', quizzes=quizzes)

# Logout route
@app.route('/logout')
def logout():
    session.pop('username', None)
    flash("You have been logged out.", "success")
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
